At the command prompt, enter
make
to compile all c files to executable programs.

bitops.c : how different binary/unary bit/logical operators work on int
unsignedbitops.c : how differnt binary/unary bit/logical operators work for unsigned numbers (different behavior in right shift from bitops.c)
float.c : floating point number doesn't satisfy associativity rule
int.c : int is finite and can have overflow
memorybug.c : a subtle memory bug (array out of bound)
precision.c : print out a floating number to any precision after decimal point
showbytes.c : showing little endian byte ordering of data
sizeof.c : showing the size (number of bytes) of different data type
